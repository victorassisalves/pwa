# Promises

In this lab you learn how to use JavaScript Promises.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_promises.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-promises).

## Note

This is not an official Google product.

Images from [Wikimedia Commons](https://commons.wikimedia.org/wiki/Main_Page).