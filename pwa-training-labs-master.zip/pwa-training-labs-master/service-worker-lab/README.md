## Lab: Scripting the Service Worker

In this lab you learn how to create a basic service worker script, install it, and do simple debugging.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_scripting_the_service_worker.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-scripting-the-service-worker).

## Note

This is not an official Google product.
