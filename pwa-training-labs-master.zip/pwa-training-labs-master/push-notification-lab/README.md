## Lab: Integrating Web Push

In this lab you learn how to use the Notification API and Push API.
It uses the web-push library to push a message with data to the service workers
from a Node.js server.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_integrating_web_push.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-integrating-web-push).

## Note

This is not an official Google product.
