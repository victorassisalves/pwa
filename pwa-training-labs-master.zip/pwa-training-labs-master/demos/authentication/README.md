# Authentication demo

This sample application can be used to demonstrate how to implement client-side
Google sign-in.

This content is part of Google's [Progressive Web App Training](https://developers.google.com/web/ilt/pwa/),
which is also available on [GitBook](https://www.gitbook.com/book/google-developer-training/progressive-web-apps-ilt-codelabs/details).

## Note

This is not an official Google product.

All images are are licensed CC0 - no attribution required.
