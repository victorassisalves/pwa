# Migrating to Workbox from sw-precache and sw-toolbox

This lab shows you how to take an existing PWA that uses sw-precache and
sw-toolbox and migrate it to Workbox to create optimal service worker code.

## Getting started
To get started, check out the [instructions on developers.google.com](https://developers.google.com/web/ilt/pwa/lab-migrating-to-workbox-from-sw-precache-and-sw-toolbox).

## Note

This is not an official Google product.

All images are are licensed CC0 - no attribution required.
