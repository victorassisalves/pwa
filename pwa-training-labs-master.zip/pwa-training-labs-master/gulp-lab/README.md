## Lab: Gulp Setup

In this lab you learn how to automate tasks with [gulp](https://gulpjs.com/),
a build tool and task runner.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_gulp_setup.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-gulp-setup).

## Note

This is not an official Google product.

All images are are licensed CC0 - no attribution required.
