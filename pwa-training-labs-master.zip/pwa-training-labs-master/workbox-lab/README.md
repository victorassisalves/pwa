## Lab: Workbox

In this lab, you’ll use [Workbox](https://workboxjs.org/) to convert a web site
into a Progressive Web App with offline functionality and fast performance.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_workbox.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-workbox).

## Note

This is not an official Google product.

All images are are licensed CC0 - no attribution required.
