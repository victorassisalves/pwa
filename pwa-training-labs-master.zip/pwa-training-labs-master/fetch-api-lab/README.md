## Lab: Fetch API

In this lab you learn how to use the Fetch API, a simple interface for fetching resources, and an improvement over the XHMLHttpRequest API.

## Getting started

To get started, check out the instructions in
[GitBook](https://google-developer-training.gitbooks.io/progressive-web-apps-ilt-codelabs/content/docs/lab_fetch_api.html)
or on [developers.google.com](https://developers.google.com/web/ilt/pwa/lab-fetch-api).

## Note

This is not an official Google product.

All images are are licensed CC0 - no attribution required.

